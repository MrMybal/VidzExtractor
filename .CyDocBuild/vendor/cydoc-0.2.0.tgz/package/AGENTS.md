# Working on CyDoc

These instructions apply to the CyDoc checkout. To use CyDoc in another application, start with [ai/README.md](ai/README.md); keep that application's own agent instructions. Do not replace its `AGENTS.md` with this file.

## Read first

- [README.md](README.md): project status, build commands and supported features.
- [ai/INTEGRATION.md](ai/INTEGRATION.md): package consumption, offline exports and native help links.
- [ai/AUTHORING.md](ai/AUTHORING.md): Markdown, translations, media and source extraction.
- [ai/API.md](ai/API.md): exported functions, types and module lifecycle.

## Architecture and constraints

- Reading must work through `file://` without a web server. `npm run dev` is a build watcher. Keep the generated classic-script bootstrap and local binary asset provider working.
- Exports open through `Documentation.html`; scripts, media, manifests, notices and version exports belong under `DocData/`. Keep authored `assets/` paths logical and use the reader's asset URL resolver for display. Preserve legacy entry redirects when migrating an existing export.
- Keep `src/index.ts` and its core dependencies independent of the DOM and media engines. Media modules are optional and loaded on demand. Only the mesh module needs Three.js.
- Keep `studio/` authoring dependencies separate from the reader and root npm archive. Studio uses a service for storage and collaboration, with account-free loopback-only local mode (default in Windows, explicit `--local` on the web CLI) and authenticated online mode; exported manuals still work through `file://`. Desktop integration uses CyUI/CEF and the actual CyMCPSDK runtime for SDK/MCP.
- The viewer owns the URL fragment and uses a global CSS reset. Embeddings use a dedicated page or iframe.
- Generate and package assets locally. Do not introduce runtime CDNs, remote fonts, telemetry, network-dependent search, or `fetch()` for local manifests and binary media.
- Enlargement stays inside the documentation window. Do not introduce native browser/OS fullscreen. Keep Escape, keyboard controls, touch access, reading positions and navigation scroll working.
- Keep page IDs, explicit anchors, media IDs and annotation IDs stable. Translations share page IDs and explicit anchors. Preserve existing deep links or add validated aliases.
- UI text needs French and English equivalents. Additional content locales are supported; additional UI translations and RTL are not yet implemented.
- Design the reader for people using the application. Keep AI instructions in the separate `DocAI.md` sidecar and keep maintenance instructions, audits and verification histories out of human content, navigation and search. `audience: internal` / `audience: ai` pages are excluded by the compiler.
- Exports require English originals (`defaultLocale: en`) and complete, nonempty, current French translations. Fail before publication when either is incomplete. Additional incomplete locales are withheld. Older/custom manifests show only complete languages, with no mixed-language fallback banner.
- Application integrations keep documentation inputs and tooling in `App/.CyDocBuild/` and export to `App/Documentation/`. The default CLI lookup prefers `.CyDocBuild/cydoc.config.json`; its sibling output must stay inside the application root. This library checkout retains its own maintained demo/source layout.
- Publish annotated/API documentation, includes and modules, never raw implementation listings. `apiIndex` generates API-only file references; legacy `sourceIndex` is a compatibility alias for that behavior.
- Use an application's existing local logo through the optional configuration/manifest `logo` field. If it has none, omit the field and preserve the default book icon and loading-error fallback. Keep integration guidance explicit about this choice.
- Preserve MIT licensing and dependency notices. Do not claim native, codec or WebGL compatibility without testing the target.

## Edit the source

| Location | Responsibility |
| --- | --- |
| `src/index.ts`, `src/types.ts` | DOM-free routing, registry, search and public contracts |
| `src/viewer.ts`, `src/reader-tools.ts`, `src/reading-view.ts` | Reader, personal tools and reading position |
| `src/viewer.css`, `src/themes.ts`, `src/icons.ts`, `src/tooltips.ts` | Shared appearance, themes and tooltips |
| `src/modules/` | Optional readers and their shared controls |
| `tools/` | Compilation, imports, extraction and local export |
| `web/` | Local entry point and generated-reader bootstrap |
| `docs/fr/`, `docs/en/`, `assets/` | Demo content and original sample media |
| `examples/`, `tests/` | Integration examples and automated checks |
| `ai/`, `llms.txt` | Guidance shipped to agents consuming the library |
| `studio/` | Optional web editor, authenticated workspace service, SDK/MCP and Windows shell |
| `website/` | Static bilingual showcase sources and real product screenshots; builds to `dist/website/` with the original HTML manual |

Edit these inputs, then build. `dist/` and example `.output/` directories are generated; do not hand-edit or commit them. Do not run demo-generation scripts merely to edit one page: they can overwrite maintained examples.

## Validate changes

Use Node.js 22 or later. Run `npm ci` when dependencies are missing, then `npm test` for code changes; it builds the library and runs the suite. `npm run check` checks types without emitting files; `npm run size` measures the generated bundles.

For documentation-only edits, check relative links, examples and packaged files. If examples or configuration change, build a separate consumer manual with the CLI. Both `cydoc build` and `cydoc check` write an export. Use a temporary project subdirectory for fixtures.

The Happy DOM tests are component fixtures, not a browser rendering or native-device compatibility check. Report which checks actually ran and any remaining limits. Preserve unrelated user changes. Add tests when they verify a meaningful behavior or regression.

For Studio changes, install its separate lockfile with `npm ci --prefix studio`, then run `npm run build --prefix studio` and `npm test --prefix studio`. `node studio/desktop/test.mjs` exercises the real Python SDK/MCP using its prepared private runtime (`CYDOC_TEST_PYTHON` overrides the interpreter). Keep account databases, credential stores, runtime dependencies, profiles and generated distributions out of Git. Do not claim multi-node hosting, native browser sandboxing or untested platform compatibility.

Studio updates use the installed CyInstaller engine through `studio/desktop/app/updater.py`, with an explicit installation root for the nested executable. Follow `.cyinstaller/README.md`; preserve the permanent app ID/trust key and data paths. Never manufacture `_cyinstall` in a payload, keep signing private keys outside Git, and do not add a second payload updater. Confirm startup only after the editor/data initialized signal. Exercise save-before-close, real sandbox installation/update/relaunch/rollback and retained data before distributing a setup. Packaging and signed local release generation do not authorize publication or a workflow.

For an explicitly requested release, follow [the local publication guide](ai/RELEASING.md). Build and scan locally; do not invoke GitHub Actions. Keep published downloads until their verified replacement is ready, and never advertise an untested platform package. When desktop control is unavailable, use the headless checks and report native rendering separately.

For showcase changes, use `npm run website:build` and `npm run website:preview`. Keep documentation links pointed at the generated `manual/Documentation.html` reader, with the selected locale. Validate desktop/mobile rendering, screenshot enlargement and both languages in a browser. Do not add a deployment workflow or publish unless requested.

## Keep agent guidance accurate

Update `ai/` when changing public APIs, supported configuration, media options or integration constraints. Keep its links usable in the npm archive, whose `files` allowlist is in `package.json`. Do not advertise commands, adapters, codecs or source parsers that the implementation does not provide.

## README convention

Before changing a README, read [the convention](ai/readme/README.md), [its agent instructions](ai/readme/DocAI.md) and [the complete template](ai/readme/TEMPLATE.md). CyDoc's GitHub header uses a native three-column HTML table with visible borders: useful links and languages on the left, the existing logo in the middle, and the application license, exact versions, explicit stage and available download on the right. Put versions and stage directly below the license. Keep the name and optional author credit below the table. Preserve this composition in both README languages.

The local preview must render that same table and its borders. Do not use preview-only CSS to simulate a GitHub layout, hide native borders, or replace the accepted columns with a centered stack. Explain renderer limitations before presenting a design. When publication is authorized, inspect the actual rendered GitHub README before reporting visual success; otherwise state that GitHub rendering remains unverified. Keep the optional `By <author>` credit project-specific and the optional AI Usage box last.
